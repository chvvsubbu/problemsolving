package com.lists;

import java.util.ArrayList;



public class ArrayListExample {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList a= new ArrayList();
		a.add(null);
		a.add(null);
		System.out.println(a.size());
		

	}

}
