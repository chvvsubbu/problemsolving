package com.lists;

public class StackArray {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
